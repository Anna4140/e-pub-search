package servlets;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class GoogleBooks {
	private static final String API_KEY = "AIzaSyAmyVW7vLrwA6nJGF5W2Cd65y5DWxty52U";
	private ArrayList<Book> books;
	
	public GoogleBooks() {
		books = new ArrayList<Book>();
	}
	
	private void performSearch(String input) {
		try {
			URL url = new URL("https://www.googleapis.com/books/v1/volumes?q="+input+"&key="+API_KEY);
			
			JSONTokener tokener = new JSONTokener(url.openStream());
			JSONObject json = new JSONObject(tokener);
			JSONArray items = json.getJSONArray("items");
			
			for (int i=0; i < items.length(); i++) {
				JSONObject details = ((JSONObject) items.get(i)).getJSONObject("volumeInfo");
				ArrayList<String> authors = new ArrayList<String>();
				if (details.has("authors")) {
					JSONArray authorsArray = details.getJSONArray("authors");
				
					for (int j=0; j < authorsArray.length(); j++)
						authors.add(authorsArray.getString(j));
				}
				
				books.add(new Book(authors, details.getString("title"), details.has("subtitle") ? details.getString("subtitle") : "", details.has("description") ? details.getString("description") : ""));
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void search(String phrase) {
		performSearch(phrase);
	}
	
	public void search(String phrase, String author) {
		performSearch(phrase+"+inauthor:"+author);
	}
	
	public ArrayList<Book> getBooks() {
		return this.books;
	}
	
	public class Book {
		private ArrayList<String> authors;
		private String title;
		private String description;
		private String subtitle;
		
		public Book(ArrayList<String> authors, String title, String subtitle, String description) {
			this.authors = authors;
			this.title = title;
			this.subtitle = subtitle;
			this.description = description;
		}
		
		public ArrayList<String> getAuthor() {
			return this.authors;
		}
		
		public String getTitle() {
			return this.title;
		}
		
		public String getDescription() {
			return this.description;
		}
		
		public String getSubtitle() {
			return this.subtitle;
		}
	}
}
