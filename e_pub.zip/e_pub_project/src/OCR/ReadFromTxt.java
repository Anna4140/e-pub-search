package OCR;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import common_things.Common_Things;

@WebServlet("/ReadFromTxt")
public class ReadFromTxt extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ReadFromTxt() {
        super();
    }

    public void read(String fileName, String fileNameGiven){
    	try{
    		Class.forName("com.mysql.jdbc.Driver");
    		
    		//creating connection with the database 
    		Connection con = DriverManager.getConnection
    				("jdbc:mysql://localhost:3306/e_pub","root","admin");
    		
    		String _fileName = fileName;
    		String _fileNameGiven = fileNameGiven;
    		
    		String plainText = "";
    		
    		BufferedReader in = new BufferedReader(new FileReader("C:\\Tesseract-OCR\\" + _fileName + ".txt"));
    		String line;
    		while((line = in.readLine()) != null)
    		{
    			plainText = plainText + " " + line;
    		}
    		in.close();
    		
    		PreparedStatement ps1 = con.prepareStatement("insert into documents (title, content) values(?,?)");
    		
    		ps1.setString(1, _fileNameGiven);
    		ps1.setString(2, plainText);
    		
    		int n = ps1.executeUpdate();	
    	}
    	catch (Exception e){
    		
    	}
    	
    }

}
