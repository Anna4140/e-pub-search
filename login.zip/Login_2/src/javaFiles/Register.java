package javaFiles;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Register() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String login = request.getParameter("login");
		String pass1 = request.getParameter("pass1");
		String pass2 = request.getParameter("pass2");
		
		if (pass1.equals(pass2)){
			String pass = pass1;
			boolean st = false;
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection
						("jdbc:mysql://localhost:3306/login_db","root","admin");
				PreparedStatement ps = con.prepareStatement
						("INSERT INTO users(login, pass, name) VALUES(?, ?, ?)");
				ps.setString(1, login);
				ps.setString(2, pass);
				ps.setString(3, name);

				ps.executeUpdate();
				st = true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(st)
			{
				RequestDispatcher rs = request.getRequestDispatcher("Welcome");
				rs.forward(request, response);
			}
			else
			{
				out.println("Username " + login + " already exists. Please choose another login.");
				RequestDispatcher rs = request.getRequestDispatcher("registerForm.html");
				rs.include(request, response);
			}
		}
		else{
			
		}
		//doGet(request, response);
	}

}
