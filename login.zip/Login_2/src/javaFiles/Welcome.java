package javaFiles;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Welcome")
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Welcome() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8");
        
		String login = request.getParameter("login");
		String name = "";
		boolean st = false;
		
		try{
			//loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			//creating connection with the database 
			Connection con = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/login_db","root","admin");
			PreparedStatement ps = con.prepareStatement
					("select name from users where login=?");
			ps.setString(1, login);
			ResultSet rs = ps.executeQuery();
			st = rs.next();
			name = rs.getString("name");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if (st){
			out.println("Welcome " + name + "!");			
		}		
	}
}
