package javaFiles;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Login() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();

		String login = request.getParameter("login");
		String pass = request.getParameter("pass");
		
		boolean st = false;
		try{
			//loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			//creating connection with the database 
			Connection con = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/login_db","root","admin");
			PreparedStatement ps = con.prepareStatement
					("select * from users where login=? and pass=?");
			ps.setString(1, login);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			st = rs.next();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if(st)
		{
			RequestDispatcher rs = request.getRequestDispatcher("Welcome");
			rs.forward(request, response);
		}
		else
		{
			out.println("Username or Password incorrect. Please try again with appropriate credentials.");
			RequestDispatcher rs = request.getRequestDispatcher("loginForm.html");
			rs.include(request, response);
		}

		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
