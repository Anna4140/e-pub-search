package servlets;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlets.GoogleBooks.Book;

@WebServlet ("/GoogleBooksServlet")
public class GoogleBooksServlet extends HttpServlet {

   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
      PrintWriter out = response.getWriter();
      
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet google books</title>");  
      out.println("</head>");
      out.println("<body>");
      
      String query = request.getParameter("search");
      
      GoogleBooks books = new GoogleBooks();
      books.search(query);
      ArrayList<Book> booksList = books.getBooks();
      
      for (int i=0; i<booksList.size(); i++) {
    	  out.println(booksList.get(i).getTitle() + "<br/>");
    	  //out.println("<br/>");
      }
      
      out.println("</body></html>");
   }
}