package servlets;

import java.io.File;
import java.net.URL;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import java.sql.*;


public class UploadOnlineServlet extends HttpServlet {

	private String filePath;
	private File file ;

	public void init( ){
		// Get the file location where it would be stored.
		filePath = getServletContext().getInitParameter("file-upload"); 
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {

		response.setContentType("text/html");
		java.io.PrintWriter out = response.getWriter( );
		
		try{ 
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Servlet upload</title>");  
			out.println("</head>");
			out.println("<body>");

			Class.forName("com.mysql.jdbc.Driver");

			//creating connection with the database 
			Connection con = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/e_pub","root","admin");

			String urlFile = request.getParameter("urlFile");

			String fileName = urlFile.substring(urlFile.lastIndexOf("/") + 1);

			FileUtils.copyURLToFile(new URL(urlFile), new File(filePath + "/" + fileName + ".pdf"));

			out.println("Uploaded Filename: " + fileName + "<br>");

			file = new File(filePath + "\\" + fileName + ".pdf");

			//Extracting text from pdf file
			PDDocument pdf = PDDocument.load(file);
			PDFTextStripper stripper = new PDFTextStripper();
			String plainText = stripper.getText(pdf);


			PreparedStatement ps = con.prepareStatement("insert into documents (title, content) values(?,?)");

			ps.setString(1, fileName);
			ps.setString(2, plainText);

			int n = ps.executeUpdate();

			out.println("</body>");
			out.println("</html>");
		}catch(Exception ex) {
			System.out.println(ex);
		}
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
			throw new ServletException("GET method used with " + getClass( ).getName( )+": POST method required.");
	} 
}