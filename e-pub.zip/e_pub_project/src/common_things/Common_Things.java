package common_things;

public class Common_Things {
	public static String url="http://localhost:8080/OCR";
	public static String upload_path="C:\\Tesseract-OCR";
}