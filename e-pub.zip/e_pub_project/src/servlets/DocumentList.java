package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

@WebServlet("/DocumentList")
public class DocumentList extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public DocumentList() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		doGet(request, response);
	
		response.setContentType("text/html;charset=UTF-8");
        
		//String searchText = request.getParameter("searchText");
		String titleList = "";
		boolean st = false;
		
		try{
			//loading drivers for mysql
			Class.forName("com.mysql.jdbc.Driver");

			//creating connection with the database 
			Connection con = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/e_pub","root","admin");
			
			PreparedStatement ps = con.prepareStatement("select title from documents");
			//ps.setString(1, searchText);
			ResultSet rs = ps.executeQuery();
			st = true;
			while(rs.next()){
				titleList = titleList + " <br/> " + rs.getString("title");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if (st){
			
			out.println("Your documents: '" + titleList + "'.");			
		}
	}

}
