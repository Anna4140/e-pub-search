package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Manage
 */
@WebServlet("/Manage")
public class Manage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Manage() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		//String email = request.getParameter("email");
		String pass = request.getParameter("pass");

		String delete = request.getParameter("delete");
		String email= "";

		Cookie ck[]=request.getCookies();  
		if(ck!=null){  
			email=ck[0].getValue(); }

		boolean st = false;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection
					("jdbc:mysql://localhost:3306/e_pub","root","admin");

			if (firstname.length()>0){
				PreparedStatement ps = con.prepareStatement
						("UPDATE user SET firstName=? WHERE email=?");
				ps.setString(1, firstname);			
				ps.setString(2, email);
				ps.executeUpdate();}

			if (lastname.length()>0){
				PreparedStatement ps = con.prepareStatement
						("UPDATE user SET lastName=? WHERE email=?");
				ps.setString(1, lastname);			
				ps.setString(2, email);
				ps.executeUpdate();}

			if (pass.length()>0){

				PreparedStatement ps = con.prepareStatement
						("UPDATE user SET password=? WHERE email=?");
				ps.setString(1, pass);			
				ps.setString(2, email);
				ps.executeUpdate();}	

			if (delete != null){

				PreparedStatement ps = con.prepareStatement
						("DELETE from user WHERE email=?");					
				ps.setString(1, email);
				ps.executeUpdate();		}	

			st = true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		if(st)
		{
			RequestDispatcher rs = request.getRequestDispatcher("loginUser.html");
			rs.forward(request, response);
		}
		else
		{
			out.println("Error.");
			RequestDispatcher rs = request.getRequestDispatcher("manageProfile.html");
			rs.include(request, response);
		}


		//doGet(request, response);
	}




}

