package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.parser.Cookie;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Register() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String pass1 = request.getParameter("pass1");
		String pass2 = request.getParameter("pass2");
		
		
		if (pass1.equals(pass2)){
			String pass = pass1;
			boolean st = false;
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection
						("jdbc:mysql://localhost:3306/e_pub","root","wap123456");
				PreparedStatement ps = con.prepareStatement
						("INSERT INTO user(firstName, lastName, password, email) VALUES(?, ?, ?, ?)");
				ps.setString(1, firstname);
				ps.setString(2, lastname);
				ps.setString(3, pass);
				ps.setString(4, email);

				ps.executeUpdate();
				st = true;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			if(st)
			{
				RequestDispatcher rs = request.getRequestDispatcher("Login");
				rs.forward(request, response);
			}
			else
			{
				out.println("Username with email: " + email + " already exists. Please choose another login.");
				RequestDispatcher rs = request.getRequestDispatcher("registerForm.html");
				rs.include(request, response);
			}
		}
		else{
			
		}
		//doGet(request, response);
	}

}
